import numpy as np
from sklearn.linear_model import LinearRegression as lr
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures as PF
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error as mse
##import pandas as pd
lr_model=lr(normalize=True)
listx=[]
i=int(input('enter the number of random numbers you want to generate\n'))
p=int(input('\n enter the power of the predicting equation:'))
x=np.linspace(0,100,i).reshape(-1,1)
x_seq = np.linspace(-50,150,300).reshape(-1,1)
y=4*x+3+((np.random.rand(i,1)-0.5)*100)
polyreg=make_pipeline(PF(p),lr())
polyreg.fit(x,y)
plt.scatter(x,y)
plt.plot(x_seq,polyreg.predict(x_seq),'r--')
plt.ylim(min(y)-50,max(y)+50)
plt.show()
#mse(y,polyreg.predict(x)))
