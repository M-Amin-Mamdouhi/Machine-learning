import numpy as np
from sklearn.linear_model import LinearRegression as lr
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures as PF
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error as mse
from sklearn.model_selection import learning_curve as lc
##import pandas as pd
lr_model=lr(normalize=True)
listcolor=['m--','y--','k--','r--','o--']
listofpower=['1']
lmset=[]
lmsetr=[]
c=0
i=200
noise1 = np.random.normal(0,2000,160).reshape(-1,1)
noise2 = np.random.normal(0,2000,40).reshape(-1,1)
#p=int(input('\n enter the power of the predicting equation:'))
x=np.linspace(0,10,i).reshape(-1,1)
x_test=(np.random.rand(40,1)*10).reshape(-1,1)
x_train=(np.random.rand(160,1)*10).reshape(-1,1)
x_seq = np.linspace(-1,11,300).reshape(-1,1)
y_train=4*(x_train*x_train*x_train*x_train)+5*(x_train*x_train*x_train)+2*(x_train*x_train)+7*x_train+6+noise1
y_test=4*(x_test*x_test*x_test*x_test)+5*(x_test*x_test*x_test)+2*(x_test*x_test)+7*x_test+6+noise2
for p in listofpower:
    train_sizes, train_scores, validation_scores = lc(estimator = make_pipeline(PF(int(p)),lr()),X = x_train,y = y_train)
    train_scores_mean = train_scores.mean(axis = 1)
    validation_scores_mean = validation_scores.mean(axis = 0)
    plt.plot(train_sizes, train_scores_mean, label = 'Training error')
    plt.plot(train_sizes.reshape(-1,1), validation_scores_mean.reshape(-1,1), label = 'Validation error')

plt.show()
#plt.plot(x_test,y_test,'co')
#plt.plot(x_train,y_train,'bo')
##listp=[1,2,4,8,16]
##for p in listp:
##    polyreg=make_pipeline(PF(p),lr())
##    polyreg.fit(x_train,y_train)
##    lmset.append(mse(y_test,polyreg.predict(x_test))**0.5)
##    lmsetr.append(mse(y_train,polyreg.predict(x_train))**0.5)
##    c+=1
###plt.ylim(min(y_train)-1000,max(y_train)+1000)
##plt.plot(listp,lmset,'r--',label='test error')
##plt.plot(listp,lmsetr,'y--',label='train error')
##plt.legend()
##plt.show()
