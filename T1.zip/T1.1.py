import numpy as np
from sklearn.linear_model import LinearRegression as lr
import matplotlib.pyplot as plt
##import pandas as pd
"""'part 1'
lr_model=lr(normalize=True)
i=int(input('please enter the number of required numbers:'))
x=np.random.rand(i,1)*100
a=np.random.rand(i,1)*100
y=4*x+5
y=y+a
    
x=x.reshape(-1,1)
y=y.reshape(-1,1)

    
lr_model.fit(x,y)
x_line = np.arange(0,100,0.1).reshape(-1,1)
##x_line = np.hstack((x_line))
y_line = lr_model.predict(x_line)
plt.plot(x,y,'ro')
plt.plot(x_line,y_line,'b--')
plt.show()"""
"""'part 2'
lr_model=lr(normalize=True)
i=int(input('please enter the number of required numbers:'))
x=np.random.rand(i,1)*10
a=np.random.rand(i,1)*10
y=4*x+5
y=y+a
    
x=x.reshape(-1,1)
y=y.reshape(-1,1)
np.hstack((x,x**2,x**3,x**4))
    
lr_model.fit(x,y)
x_line = np.arange(-100,100,0.1).reshape(-1,1)
x_line = np.hstack((x_line,x_line**2,x_line**3,x_line**4)).reshape(-1,1)
y_line = lr_model.predict(x_line)
plt.plot(x,y,'ro')
plt.plot(x_line,y_line,'b--')
plt.xlim((-50,50))
plt.ylim((-50,50))
plt.show()"""
"""'part 3'
lr_model=lr(normalize=True)
i=int(input('please enter the number of required numbers:'))
x=np.random.rand(i,1)*10
a=np.random.rand(i,1)*10
y=4*x+5
y=y+a
    
x=x.reshape(-1,1)
y=y.reshape(-1,1)
np.hstack((x,x**2,x**3,x**4,x**5,x**6,x**7,x**8,x**9,x**10,x**11,x**12,x**13,x**14,x**15,x**16))
    
lr_model.fit(x,y)
x_line = np.arange(-100,100,0.1).reshape(-1,1)
x_line = np.hstack((x_line,x_line**2,x_line**3,x_line**4,x_line**5,x_line**6,x_line**7,x_line**8,x_line**9,x_line**10,x_line**11,x_line**12,x_line**13,x_line**14,x_line**15,x_line**16)).reshape(-1,1)
y_line = lr_model.predict(x_line)
plt.plot(x,y,'ro')
plt.plot(x_line,y_line,'b--')
plt.xlim((-10,10))
plt.ylim((-50,50))
plt.show()"""
